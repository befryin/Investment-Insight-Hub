// Portfolio analytics: holdings, ACB, gains, returns, allocation.
import { all, one } from "./db/sqlite";

export type Holding = {
  security_id: number;
  symbol: string;
  name: string | null;
  asset_class: string | null;
  region: string | null;
  account_id: number;
  account_name: string;
  quantity: number;
  book_value: number; // ACB total
  avg_cost: number;
  market_price: number;
  market_value: number;
  unrealized: number;
  unrealized_pct: number;
  currency: string;
};

type TxRow = {
  id: number;
  account_id: number;
  security_id: number | null;
  trade_date: string;
  type: string;
  quantity: number;
  price: number;
  amount: number;
  fees: number;
  currency: string;
};

// Average cost base method (Canadian ACB).
export async function computeHoldings(filter?: { accountId?: number; portfolioId?: number }): Promise<Holding[]> {
  let where = "1=1";
  const params: unknown[] = [];
  if (filter?.accountId) { where += " AND t.account_id = ?"; params.push(filter.accountId); }
  if (filter?.portfolioId) { where += " AND a.portfolio_id = ?"; params.push(filter.portfolioId); }

  const txs = await all<TxRow & { symbol: string; sec_name: string | null; asset_class: string | null; region: string | null; account_name: string; sec_currency: string }>(
    `SELECT t.*, s.symbol, s.name as sec_name, s.asset_class, s.region, s.currency as sec_currency, a.name as account_name
     FROM transactions t
     JOIN accounts a ON a.id = t.account_id
     LEFT JOIN securities s ON s.id = t.security_id
     WHERE ${where} AND t.security_id IS NOT NULL
     ORDER BY t.trade_date ASC, t.id ASC`,
    params,
  );

  const map = new Map<string, Holding & { _qty: number; _book: number }>();

  for (const t of txs) {
    if (!t.security_id) continue;
    const key = `${t.account_id}:${t.security_id}`;
    let h = map.get(key);
    if (!h) {
      h = {
        security_id: t.security_id,
        symbol: t.symbol,
        name: t.sec_name,
        asset_class: t.asset_class,
        region: t.region,
        account_id: t.account_id,
        account_name: t.account_name,
        quantity: 0,
        book_value: 0,
        avg_cost: 0,
        market_price: 0,
        market_value: 0,
        unrealized: 0,
        unrealized_pct: 0,
        currency: t.sec_currency || t.currency || "CAD",
        _qty: 0,
        _book: 0,
      };
      map.set(key, h);
    }
    if (t.type === "BUY") {
      h._qty += t.quantity;
      h._book += t.quantity * t.price + (t.fees || 0);
    } else if (t.type === "SELL") {
      const avg = h._qty > 0 ? h._book / h._qty : 0;
      h._book -= avg * t.quantity;
      h._qty -= t.quantity;
      if (h._qty < 1e-9) { h._qty = 0; h._book = 0; }
    } else if (t.type === "ROC") {
      // Return of capital reduces ACB
      h._book -= Math.abs(t.amount);
    } else if (t.type === "SPLIT") {
      // price field carries new/old ratio
      if (t.price > 0) h._qty *= t.price;
    }
  }

  // attach quotes
  const quotes = await all<{ security_id: number; price: number }>(`SELECT security_id, price FROM quotes`);
  const qMap = new Map(quotes.map((q) => [q.security_id, q.price]));

  const result: Holding[] = [];
  for (const h of map.values()) {
    if (h._qty < 1e-9) continue;
    h.quantity = h._qty;
    h.book_value = h._book;
    h.avg_cost = h._book / h._qty;
    h.market_price = qMap.get(h.security_id) ?? h.avg_cost;
    h.market_value = h.quantity * h.market_price;
    h.unrealized = h.market_value - h.book_value;
    h.unrealized_pct = h.book_value !== 0 ? h.unrealized / h.book_value : 0;
    result.push(h);
  }
  return result.sort((a, b) => b.market_value - a.market_value);
}

export async function cashBalance(accountId: number): Promise<number> {
  const row = await one<{ bal: number }>(
    `SELECT COALESCE(SUM(amount),0) AS bal FROM transactions WHERE account_id = ?`,
    [accountId],
  );
  return row?.bal ?? 0;
}

export async function allCashBalances(): Promise<Map<number, number>> {
  const rows = await all<{ account_id: number; bal: number }>(
    `SELECT account_id, COALESCE(SUM(amount),0) AS bal FROM transactions GROUP BY account_id`,
  );
  return new Map(rows.map((r) => [r.account_id, r.bal]));
}

// Realized capital gains (ACB method) per year
export async function realizedGains(year?: number): Promise<Array<{ symbol: string; year: number; proceeds: number; cost: number; gain: number }>> {
  const txs = await all<TxRow & { symbol: string }>(
    `SELECT t.*, s.symbol FROM transactions t LEFT JOIN securities s ON s.id = t.security_id
     WHERE t.security_id IS NOT NULL AND t.type IN ('BUY','SELL','ROC','SPLIT')
     ORDER BY t.trade_date ASC, t.id ASC`,
  );
  type State = { qty: number; book: number };
  const state = new Map<string, State>();
  const out: Array<{ symbol: string; year: number; proceeds: number; cost: number; gain: number }> = [];
  for (const t of txs) {
    const key = `${t.account_id}:${t.security_id}`;
    let s = state.get(key);
    if (!s) { s = { qty: 0, book: 0 }; state.set(key, s); }
    if (t.type === "BUY") { s.qty += t.quantity; s.book += t.quantity * t.price + (t.fees || 0); }
    else if (t.type === "SELL") {
      const avg = s.qty > 0 ? s.book / s.qty : 0;
      const cost = avg * t.quantity;
      const proceeds = t.quantity * t.price - (t.fees || 0);
      const gain = proceeds - cost;
      const y = Number(t.trade_date.slice(0, 4));
      out.push({ symbol: t.symbol, year: y, proceeds, cost, gain });
      s.book -= cost;
      s.qty -= t.quantity;
      if (s.qty < 1e-9) { s.qty = 0; s.book = 0; }
    } else if (t.type === "ROC") {
      s.book -= Math.abs(t.amount);
    } else if (t.type === "SPLIT" && t.price > 0) {
      s.qty *= t.price;
    }
  }
  return year ? out.filter((r) => r.year === year) : out;
}

// Time-Weighted Return (Modified Dietz on monthly buckets) and Money-Weighted Return (XIRR).
// Returns annualized values.

type Flow = { date: Date; amount: number };

export async function getCashflows(accountId?: number): Promise<Flow[]> {
  let where = "type IN ('DEPOSIT','WITHDRAWAL','CONTRIB','WITHDRAW_REG','BUY','SELL','DIV','INT','CG_DIST','ROC','FEE')";
  const params: unknown[] = [];
  if (accountId) { where += " AND account_id = ?"; params.push(accountId); }
  const rows = await all<{ trade_date: string; amount: number; type: string }>(
    `SELECT trade_date, amount, type FROM transactions WHERE ${where} ORDER BY trade_date ASC`,
    params,
  );
  // External cashflows only (deposits/withdrawals/contributions)
  const ext: Flow[] = [];
  for (const r of rows) {
    if (["DEPOSIT", "CONTRIB"].includes(r.type)) ext.push({ date: new Date(r.trade_date), amount: -Math.abs(r.amount) });
    if (["WITHDRAWAL", "WITHDRAW_REG"].includes(r.type)) ext.push({ date: new Date(r.trade_date), amount: Math.abs(r.amount) });
  }
  return ext;
}

export async function totalPortfolioValue(filter?: { accountId?: number; portfolioId?: number }): Promise<{ market: number; book: number; cash: number }> {
  const holdings = await computeHoldings(filter);
  const market = holdings.reduce((s, h) => s + h.market_value, 0);
  const book = holdings.reduce((s, h) => s + h.book_value, 0);
  let cash = 0;
  if (filter?.accountId) cash = await cashBalance(filter.accountId);
  else {
    const map = await allCashBalances();
    if (filter?.portfolioId) {
      const accts = await all<{ id: number }>(`SELECT id FROM accounts WHERE portfolio_id = ?`, [filter.portfolioId]);
      cash = accts.reduce((s, a) => s + (map.get(a.id) ?? 0), 0);
    } else {
      cash = Array.from(map.values()).reduce((s, v) => s + v, 0);
    }
  }
  return { market, book, cash };
}

// XIRR for money-weighted return
export function xirr(flows: Array<{ date: Date; amount: number }>, guess = 0.1): number | null {
  if (flows.length < 2) return null;
  const t0 = flows[0].date.getTime();
  const days = (d: Date) => (d.getTime() - t0) / (1000 * 60 * 60 * 24 * 365);
  const npv = (rate: number) => flows.reduce((s, f) => s + f.amount / Math.pow(1 + rate, days(f.date)), 0);
  const dnpv = (rate: number) => flows.reduce((s, f) => {
    const t = days(f.date);
    return s - (t * f.amount) / Math.pow(1 + rate, t + 1);
  }, 0);
  let rate = guess;
  for (let i = 0; i < 100; i++) {
    const v = npv(rate);
    const d = dnpv(rate);
    if (Math.abs(d) < 1e-12) break;
    const next = rate - v / d;
    if (Math.abs(next - rate) < 1e-7) return next;
    rate = next;
    if (rate < -0.999) rate = -0.999;
  }
  return Math.abs(npv(rate)) < 1 ? rate : null;
}

// Income breakdown
export async function incomeBreakdown(filter?: { year?: number; accountId?: number; type?: string }): Promise<Array<{ year: number; type: string; amount: number }>> {
  let where = "type IN ('DIV','INT','CG_DIST','ROC')";
  const params: unknown[] = [];
  if (filter?.accountId) { where += " AND account_id = ?"; params.push(filter.accountId); }
  if (filter?.type) { where += " AND type = ?"; params.push(filter.type); }
  const rows = await all<{ y: string; type: string; amount: number }>(
    `SELECT substr(trade_date,1,4) as y, type, SUM(amount) as amount
     FROM transactions WHERE ${where}
     GROUP BY y, type ORDER BY y DESC, type`,
    params,
  );
  let result = rows.map((r) => ({ year: Number(r.y), type: r.type, amount: r.amount }));
  if (filter?.year) result = result.filter((r) => r.year === filter.year);
  return result;
}

// Registered account contributions tracking
export async function registeredSummary(): Promise<Array<{ account_id: number; account_name: string; account_type: string; beneficiary: string | null; contributions: number; withdrawals: number; net: number }>> {
  const rows = await all<{ account_id: number; account_name: string; account_type: string; beneficiary: string | null; contrib: number; withdraw: number }>(
    `SELECT a.id as account_id, a.name as account_name, a.account_type, a.beneficiary,
       COALESCE(SUM(CASE WHEN t.type='CONTRIB' THEN t.amount ELSE 0 END),0) as contrib,
       COALESCE(SUM(CASE WHEN t.type='WITHDRAW_REG' THEN t.amount ELSE 0 END),0) as withdraw
     FROM accounts a LEFT JOIN transactions t ON t.account_id = a.id
     WHERE a.account_type IN ('TFSA','RRSP','RESP')
     GROUP BY a.id ORDER BY a.account_type, a.name`,
  );
  return rows.map((r) => ({
    account_id: r.account_id,
    account_name: r.account_name,
    account_type: r.account_type,
    beneficiary: r.beneficiary,
    contributions: Math.abs(r.contrib),
    withdrawals: Math.abs(r.withdraw),
    net: Math.abs(r.contrib) - Math.abs(r.withdraw),
  }));
}
