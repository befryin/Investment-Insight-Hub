export const fmtMoney = (n: number, currency = "CAD") =>
  new Intl.NumberFormat("en-CA", { style: "currency", currency, maximumFractionDigits: 2 }).format(n);

export const fmtNum = (n: number, digits = 2) =>
  new Intl.NumberFormat("en-CA", { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(n);

export const fmtPct = (n: number, digits = 2) =>
  new Intl.NumberFormat("en-CA", { style: "percent", maximumFractionDigits: digits, minimumFractionDigits: digits }).format(n);

export const fmtDate = (d: string | Date) => {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toISOString().slice(0, 10);
};

export const gainColor = (n: number) =>
  n > 0 ? "text-[color:var(--color-gain)]" : n < 0 ? "text-[color:var(--color-loss)]" : "text-muted-foreground";
