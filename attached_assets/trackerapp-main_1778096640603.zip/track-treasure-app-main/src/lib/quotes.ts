// Quote fetching via server route proxy (bypasses CORS).
export type Quote = { symbol: string; price: number; change: number; changePct: number };

export async function fetchQuotes(symbols: string[]): Promise<Quote[]> {
  if (symbols.length === 0) return [];
  const res = await fetch(`/api/public/quotes?symbols=${encodeURIComponent(symbols.join(","))}`);
  if (!res.ok) throw new Error(`Quote fetch failed: ${res.status}`);
  const data = (await res.json()) as { quotes: Quote[] };
  return data.quotes;
}
