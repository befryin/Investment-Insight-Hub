import { useEffect, useState, useCallback, useSyncExternalStore } from "react";
import { all, one, getDb, subscribe, notifyChange } from "./sqlite";

export function useDbReady() {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    getDb()
      .then(() => !cancelled && setReady(true))
      .catch((e) => !cancelled && setError(e.message ?? String(e)));
    return () => { cancelled = true; };
  }, []);
  return { ready, error };
}

const emptySnap = Symbol("empty");
export function useQuery<T = Record<string, unknown>>(sql: string, params: unknown[] = []) {
  const key = sql + JSON.stringify(params);
  const [data, setData] = useState<T[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const version = useSyncExternalStore(
    (cb) => subscribe(cb),
    () => globalChangeVersion,
    () => 0,
  );

  useEffect(() => {
    let cancelled = false;
    all<T>(sql, params)
      .then((rows) => !cancelled && setData(rows))
      .catch((e) => !cancelled && setError(e.message ?? String(e)));
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, version]);

  return { data, error, loading: data === null && !error };
}

export function useScalar<T = unknown>(sql: string, params: unknown[] = []): T | null {
  const { data } = useQuery<Record<string, T>>(sql, params);
  if (!data || data.length === 0) return null;
  const row = data[0];
  const firstKey = Object.keys(row)[0];
  return (row[firstKey] ?? null) as T;
}

let globalChangeVersion = 0;
const origNotify = notifyChange;
export function bumpChange() {
  globalChangeVersion++;
  origNotify();
}
// re-export for ergonomic call after mutations
export { all, one };
void emptySnap;
export const useMutation = () => useCallback(() => bumpChange(), []);
