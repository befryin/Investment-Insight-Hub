// Client-side SQLite WASM database with OPFS persistence.
// Falls back to in-memory if OPFS is unavailable.

import sqlite3InitModule, { type Database, type Sqlite3Static } from "@sqlite.org/sqlite-wasm";

let dbPromise: Promise<Database> | null = null;
let sqlite3: Sqlite3Static | null = null;

const SCHEMA_VERSION = 1;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS portfolios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  portfolio_id INTEGER REFERENCES portfolios(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  account_type TEXT NOT NULL, -- TFSA, RRSP, RESP, MARGIN, CASH, 401K, IRA, ROTH
  currency TEXT NOT NULL DEFAULT 'CAD',
  institution TEXT,
  beneficiary TEXT, -- for RESP per-child
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS securities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol TEXT NOT NULL UNIQUE,
  name TEXT,
  asset_class TEXT, -- equity, fixed_income, cash, alternative, crypto
  region TEXT, -- ca, us, intl, em
  sector TEXT,
  currency TEXT DEFAULT 'CAD',
  is_etf INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  security_id INTEGER REFERENCES securities(id) ON DELETE SET NULL,
  trade_date TEXT NOT NULL,
  settle_date TEXT,
  type TEXT NOT NULL, -- BUY, SELL, DIV, INT, CG_DIST, ROC, FEE, DEPOSIT, WITHDRAWAL, CONTRIB, WITHDRAW_REG, FX, SPLIT
  quantity REAL DEFAULT 0,
  price REAL DEFAULT 0,
  amount REAL NOT NULL, -- net cash impact (+ in, - out)
  fees REAL DEFAULT 0,
  currency TEXT DEFAULT 'CAD',
  fx_rate REAL DEFAULT 1,
  notes TEXT,
  source TEXT, -- manual, csv, etf_import
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_tx_account ON transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_tx_security ON transactions(security_id);
CREATE INDEX IF NOT EXISTS idx_tx_date ON transactions(trade_date);

CREATE TABLE IF NOT EXISTS prices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  security_id INTEGER NOT NULL REFERENCES securities(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  close REAL NOT NULL,
  UNIQUE(security_id, date)
);

CREATE TABLE IF NOT EXISTS quotes (
  security_id INTEGER PRIMARY KEY REFERENCES securities(id) ON DELETE CASCADE,
  price REAL NOT NULL,
  change REAL DEFAULT 0,
  change_pct REAL DEFAULT 0,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pending_distributions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol TEXT NOT NULL,
  ex_date TEXT,
  pay_date TEXT,
  total_per_unit REAL,
  eligible_div REAL DEFAULT 0,
  non_eligible_div REAL DEFAULT 0,
  capital_gains REAL DEFAULT 0,
  return_of_capital REAL DEFAULT 0,
  interest REAL DEFAULT 0,
  foreign_income REAL DEFAULT 0,
  source_url TEXT,
  status TEXT DEFAULT 'pending', -- pending, approved, rejected
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);
`;

async function init(): Promise<Database> {
  if (typeof window === "undefined") throw new Error("DB only available in browser");
  sqlite3 = await sqlite3InitModule();
  let db: Database;
  try {
    const oo1 = sqlite3.oo1 as typeof sqlite3.oo1 & { OpfsDb?: new (path: string, mode: string) => Database };
    if ("opfs" in sqlite3 && oo1.OpfsDb) {
      db = new oo1.OpfsDb("/portfolio.sqlite3", "ct");
      console.info("[db] using OPFS persistence");
    } else {
      db = new sqlite3.oo1.DB(":memory:", "ct");
      console.warn("[db] OPFS unavailable, using in-memory database");
    }
  } catch (e) {
    console.warn("[db] OPFS init failed, fallback memory", e);
    db = new sqlite3.oo1.DB(":memory:", "ct");
  }
  db.exec("PRAGMA foreign_keys = ON;");
  db.exec(SCHEMA);
  // Ensure version
  db.exec(`CREATE TABLE IF NOT EXISTS _meta (k TEXT PRIMARY KEY, v TEXT);`);
  db.exec({
    sql: `INSERT OR REPLACE INTO _meta(k,v) VALUES('schema_version', ?)`,
    bind: [String(SCHEMA_VERSION)],
  });
  return db;
}

export function getDb(): Promise<Database> {
  if (!dbPromise) dbPromise = init();
  return dbPromise;
}

export async function exec(sql: string, params: unknown[] = []): Promise<void> {
  const db = await getDb();
  db.exec({ sql, bind: params as never });
}

export async function run(sql: string, params: unknown[] = []): Promise<number> {
  const db = await getDb();
  db.exec({ sql, bind: params as never });
  // last insert rowid
  const r = db.exec({ sql: "SELECT last_insert_rowid() AS id", returnValue: "resultRows", rowMode: "object" }) as Array<{ id: number }>;
  return r[0]?.id ?? 0;
}

export async function all<T = Record<string, unknown>>(sql: string, params: unknown[] = []): Promise<T[]> {
  const db = await getDb();
  const rows = db.exec({
    sql,
    bind: params as never,
    returnValue: "resultRows",
    rowMode: "object",
  });
  return (rows ?? []) as unknown as T[];
}

export async function one<T = Record<string, unknown>>(sql: string, params: unknown[] = []): Promise<T | null> {
  const rows = await all<T>(sql, params);
  return rows[0] ?? null;
}

export async function exportDump(): Promise<Uint8Array> {
  const db = await getDb();
  if (!sqlite3) throw new Error("sqlite not init");
  const capi = sqlite3.capi as unknown as { sqlite3_js_db_export: (db: Database) => Uint8Array };
  return capi.sqlite3_js_db_export(db);
}

// Reactive change notifier
type Listener = () => void;
const listeners = new Set<Listener>();
export function notifyChange() { listeners.forEach((l) => l()); }
export function subscribe(l: Listener): () => void {
  listeners.add(l);
  return () => listeners.delete(l);
}
