// Helpers for inserting/upserting domain rows.
import { all, run, one, exec } from "./sqlite";
import { bumpChange } from "./hooks";

export async function upsertSecurity(symbol: string, fields: Partial<{ name: string; asset_class: string; region: string; sector: string; currency: string; is_etf: number }> = {}): Promise<number> {
  const existing = await one<{ id: number }>(`SELECT id FROM securities WHERE symbol = ?`, [symbol.toUpperCase()]);
  if (existing) {
    if (Object.keys(fields).length) {
      const sets = Object.keys(fields).map((k) => `${k} = ?`).join(", ");
      await exec(`UPDATE securities SET ${sets} WHERE id = ?`, [...Object.values(fields), existing.id]);
    }
    return existing.id;
  }
  return await run(
    `INSERT INTO securities (symbol, name, asset_class, region, sector, currency, is_etf) VALUES (?,?,?,?,?,?,?)`,
    [symbol.toUpperCase(), fields.name ?? null, fields.asset_class ?? null, fields.region ?? null, fields.sector ?? null, fields.currency ?? "CAD", fields.is_etf ?? 0],
  );
}

export type NewTransaction = {
  account_id: number;
  security_id?: number | null;
  trade_date: string;
  type: string;
  quantity?: number;
  price?: number;
  amount: number;
  fees?: number;
  currency?: string;
  fx_rate?: number;
  notes?: string;
  source?: string;
};

export async function insertTransaction(t: NewTransaction): Promise<number> {
  const id = await run(
    `INSERT INTO transactions (account_id, security_id, trade_date, type, quantity, price, amount, fees, currency, fx_rate, notes, source)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      t.account_id, t.security_id ?? null, t.trade_date, t.type,
      t.quantity ?? 0, t.price ?? 0, t.amount, t.fees ?? 0,
      t.currency ?? "CAD", t.fx_rate ?? 1, t.notes ?? null, t.source ?? "manual",
    ],
  );
  bumpChange();
  return id;
}

export async function deleteTransaction(id: number) {
  await exec(`DELETE FROM transactions WHERE id = ?`, [id]);
  bumpChange();
}

export async function getSecurityIds(): Promise<Map<string, number>> {
  const rows = await all<{ id: number; symbol: string }>(`SELECT id, symbol FROM securities`);
  return new Map(rows.map((r) => [r.symbol.toUpperCase(), r.id]));
}
