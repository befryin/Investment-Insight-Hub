import { Link, useRouterState } from "@tanstack/react-router";
import { ClientOnly } from "./client-only";
import {
  LayoutDashboard, Wallet, Receipt, BarChart3, Building2,
  ArrowDownToLine, ArrowUpFromLine, FileSpreadsheet, Database, GraduationCap,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV: Array<{ to: string; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/portfolios", label: "Portfolios", icon: Building2 },
  { to: "/accounts", label: "Accounts", icon: Wallet },
  { to: "/holdings", label: "Holdings", icon: BarChart3 },
  { to: "/transactions", label: "Transactions", icon: Receipt },
  { to: "/import", label: "Import CSV", icon: ArrowDownToLine },
  { to: "/export", label: "Export CSV", icon: ArrowUpFromLine },
  { to: "/distributions", label: "ETF Distributions", icon: FileSpreadsheet },
  { to: "/registered", label: "Registered (RRSP/TFSA/RESP)", icon: GraduationCap },
  { to: "/reports", label: "Reports & Charts", icon: BarChart3 },
  { to: "/data", label: "Data & Backup", icon: Database },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden md:flex w-64 shrink-0 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border">
        <div className="px-5 py-5 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-md bg-sidebar-primary text-sidebar-primary-foreground grid place-items-center font-bold">L</div>
            <div>
              <div className="font-semibold text-sm">Ledger</div>
              <div className="text-xs text-sidebar-foreground/60">Investment tracker</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          {NAV.map((n) => {
            const active = path === n.to || (n.to !== "/" && path.startsWith(n.to));
            const Icon = n.icon;
            return (
              <Link
                key={n.to}
                to={n.to}
                className={cn(
                  "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <Icon className="size-4 shrink-0" />
                <span className="truncate">{n.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="px-4 py-3 border-t border-sidebar-border text-xs text-sidebar-foreground/60">
          Local-first · OPFS SQLite
        </div>
      </aside>
      <main className="flex-1 min-w-0 flex flex-col">
        <header className="md:hidden border-b border-border px-4 py-3 flex items-center gap-2">
          <div className="size-7 rounded-md bg-primary text-primary-foreground grid place-items-center font-bold text-sm">L</div>
          <span className="font-semibold">Ledger</span>
        </header>
        {/* Mobile nav */}
        <nav className="md:hidden border-b border-border overflow-x-auto flex gap-1 px-2 py-2">
          {NAV.map((n) => {
            const active = path === n.to || (n.to !== "/" && path.startsWith(n.to));
            return (
              <Link key={n.to} to={n.to}
                className={cn("text-xs rounded px-3 py-1.5 whitespace-nowrap", active ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground")}>
                {n.label}
              </Link>
            );
          })}
        </nav>
        <div className="flex-1 p-4 md:p-8 max-w-[1400px] w-full mx-auto">{children}</div>
      </main>
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: React.ReactNode }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
      </div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </div>
  );
}

export function DbGuard({ children }: { children: React.ReactNode }) {
  // small wrapper to hint mount-only on client
  return (
    <ClientOnly fallback={<div className="text-sm text-muted-foreground">Loading database…</div>}>
      {children}
    </ClientOnly>
  );
}

