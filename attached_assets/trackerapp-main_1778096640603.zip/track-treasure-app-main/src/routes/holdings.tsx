import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useDbReady } from "@/lib/db/hooks";
import { useEffect, useMemo, useState } from "react";
import { computeHoldings, type Holding } from "@/lib/portfolio";
import { fmtMoney, fmtNum, fmtPct, gainColor } from "@/lib/format";
import { all, exec } from "@/lib/db/sqlite";
import { bumpChange } from "@/lib/db/hooks";
import { RefreshCw, Search } from "lucide-react";
import { toast } from "sonner";
import { fetchQuotes } from "@/lib/quotes";

export const Route = createFileRoute("/holdings")({
  head: () => ({ meta: [{ title: "Holdings — Ledger" }, { name: "description", content: "Current holdings with book and market value." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [accounts, setAccounts] = useState<Array<{ id: number; name: string }>>([]);
  const [accountFilter, setAccountFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [editing, setEditing] = useState<{ id: number; price: string } | null>(null);

  async function load() {
    const filter = accountFilter !== "all" ? { accountId: Number(accountFilter) } : undefined;
    setHoldings(await computeHoldings(filter));
  }

  useEffect(() => { load(); }, [accountFilter]);
  useEffect(() => {
    all<{ id: number; name: string }>(`SELECT id, name FROM accounts ORDER BY name`).then(setAccounts);
  }, []);

  const filtered = useMemo(
    () => holdings.filter((h) => !search || h.symbol.toLowerCase().includes(search.toLowerCase()) || (h.name ?? "").toLowerCase().includes(search.toLowerCase())),
    [holdings, search],
  );

  const totals = useMemo(() => filtered.reduce((acc, h) => ({
    book: acc.book + h.book_value, market: acc.market + h.market_value, gain: acc.gain + h.unrealized,
  }), { book: 0, market: 0, gain: 0 }), [filtered]);

  async function refreshPrices() {
    setRefreshing(true);
    try {
      const symbols = Array.from(new Set(holdings.map((h) => h.symbol)));
      const quotes = await fetchQuotes(symbols);
      let updated = 0;
      for (const q of quotes) {
        const sec = await all<{ id: number }>(`SELECT id FROM securities WHERE symbol = ?`, [q.symbol]);
        if (sec[0]) {
          await exec(
            `INSERT INTO quotes (security_id, price, change, change_pct, updated_at) VALUES (?,?,?,?,datetime('now'))
             ON CONFLICT(security_id) DO UPDATE SET price=excluded.price, change=excluded.change, change_pct=excluded.change_pct, updated_at=excluded.updated_at`,
            [sec[0].id, q.price, q.change, q.changePct],
          );
          updated++;
        }
      }
      bumpChange();
      await load();
      toast.success(`Updated ${updated} price(s)`);
    } catch (e) {
      toast.error("Failed to fetch quotes: " + (e as Error).message);
    } finally {
      setRefreshing(false);
    }
  }

  async function saveManualPrice(id: number, price: number) {
    await exec(
      `INSERT INTO quotes (security_id, price, updated_at) VALUES (?,?,datetime('now'))
       ON CONFLICT(security_id) DO UPDATE SET price=excluded.price, updated_at=excluded.updated_at`,
      [id, price],
    );
    bumpChange();
    setEditing(null);
    await load();
  }

  return (
    <div>
      <PageHeader title="Holdings" description="Book value, market value and unrealized gain/loss"
        actions={<Button onClick={refreshPrices} disabled={refreshing}><RefreshCw className={`size-4 mr-1 ${refreshing ? "animate-spin" : ""}`} />Refresh prices</Button>}
      />

      <div className="flex flex-wrap gap-2 mb-4">
        <div className="relative flex-1 max-w-xs">
          <Search className="size-4 absolute left-2.5 top-2.5 text-muted-foreground" />
          <Input placeholder="Search symbol or name" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" />
        </div>
        <Select value={accountFilter} onValueChange={setAccountFilter}>
          <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All accounts</SelectItem>
            {accounts.map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="pt-6 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Account</TableHead>
                <TableHead className="text-right">Qty</TableHead>
                <TableHead className="text-right">Avg cost</TableHead>
                <TableHead className="text-right">Price</TableHead>
                <TableHead className="text-right">Book value</TableHead>
                <TableHead className="text-right">Market value</TableHead>
                <TableHead className="text-right">Unrealized</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((h) => (
                <TableRow key={`${h.account_id}-${h.security_id}`}>
                  <TableCell>
                    <div className="font-medium">{h.symbol}</div>
                    <div className="text-xs text-muted-foreground">{h.name}</div>
                    {h.asset_class && <Badge variant="outline" className="mt-1 text-[10px]">{h.asset_class}</Badge>}
                  </TableCell>
                  <TableCell className="text-sm">{h.account_name}</TableCell>
                  <TableCell className="text-right num">{fmtNum(h.quantity, 4)}</TableCell>
                  <TableCell className="text-right num">{fmtMoney(h.avg_cost, h.currency)}</TableCell>
                  <TableCell className="text-right num">
                    {editing?.id === h.security_id ? (
                      <div className="flex gap-1 justify-end">
                        <Input className="w-24 h-7 num" type="number" step="0.01" value={editing.price}
                          onChange={(e) => setEditing({ ...editing, price: e.target.value })} />
                        <Button size="sm" className="h-7" onClick={() => saveManualPrice(h.security_id, Number(editing.price))}>Save</Button>
                      </div>
                    ) : (
                      <button className="hover:underline" onClick={() => setEditing({ id: h.security_id, price: String(h.market_price) })}>
                        {fmtMoney(h.market_price, h.currency)}
                      </button>
                    )}
                  </TableCell>
                  <TableCell className="text-right num">{fmtMoney(h.book_value, h.currency)}</TableCell>
                  <TableCell className="text-right num">{fmtMoney(h.market_value, h.currency)}</TableCell>
                  <TableCell className={`text-right num ${gainColor(h.unrealized)}`}>
                    {fmtMoney(h.unrealized, h.currency)}<div className="text-xs">{fmtPct(h.unrealized_pct)}</div>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-8">No holdings. Add some BUY transactions.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
          {filtered.length > 0 && (
            <div className="flex justify-end gap-6 pt-4 mt-4 border-t border-border text-sm">
              <div>Book: <span className="num font-medium">{fmtMoney(totals.book)}</span></div>
              <div>Market: <span className="num font-medium">{fmtMoney(totals.market)}</span></div>
              <div className={gainColor(totals.gain)}>Unrealized: <span className="num font-medium">{fmtMoney(totals.gain)}</span></div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
