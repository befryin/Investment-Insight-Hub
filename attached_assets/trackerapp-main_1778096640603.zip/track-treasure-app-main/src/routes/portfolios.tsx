import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { useDbReady, useQuery } from "@/lib/db/hooks";
import { exec, run } from "@/lib/db/sqlite";
import { bumpChange } from "@/lib/db/hooks";
import { useState } from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/portfolios")({
  head: () => ({ meta: [{ title: "Portfolios — Ledger" }, { name: "description", content: "Group accounts into portfolios." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const { data: portfolios } = useQuery<{ id: number; name: string; description: string | null }>(`SELECT * FROM portfolios ORDER BY name`);
  const { data: accountsByPortfolio } = useQuery<{ portfolio_id: number | null; cnt: number }>(`SELECT portfolio_id, COUNT(*) as cnt FROM accounts GROUP BY portfolio_id`);

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");

  const counts = new Map((accountsByPortfolio ?? []).map((r) => [r.portfolio_id, r.cnt]));

  async function create() {
    if (!name.trim()) return;
    await run(`INSERT INTO portfolios (name, description) VALUES (?, ?)`, [name.trim(), desc.trim() || null]);
    setName(""); setDesc(""); setOpen(false);
    bumpChange();
    toast.success("Portfolio created");
  }

  async function remove(id: number) {
    if (!confirm("Delete portfolio? Accounts will be unassigned.")) return;
    await exec(`DELETE FROM portfolios WHERE id = ?`, [id]);
    bumpChange();
  }

  return (
    <div>
      <PageHeader title="Portfolios" description="Group accounts together to track combined performance"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="size-4 mr-1" />New portfolio</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New portfolio</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} maxLength={80} /></div>
                <div><Label>Description</Label><Input value={desc} onChange={(e) => setDesc(e.target.value)} maxLength={200} /></div>
              </div>
              <DialogFooter><Button onClick={create}>Create</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      {portfolios && portfolios.length === 0 ? (
        <Card><CardContent className="pt-6 text-sm text-muted-foreground text-center">No portfolios yet. Create your first portfolio above.</CardContent></Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {(portfolios ?? []).map((p) => (
            <Card key={p.id}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-base">{p.name}</CardTitle>
                  <Button size="icon" variant="ghost" onClick={() => remove(p.id)}><Trash2 className="size-4" /></Button>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{p.description || "No description"}</p>
                <p className="text-xs mt-2">{counts.get(p.id) ?? 0} account(s)</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
