import { createFileRoute } from "@tanstack/react-router";

type YahooQuoteResp = {
  quoteResponse?: {
    result?: Array<{
      symbol: string;
      regularMarketPrice?: number;
      regularMarketChange?: number;
      regularMarketChangePercent?: number;
    }>;
  };
};

async function fetchYahoo(symbols: string[]) {
  const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(symbols.join(","))}`;
  const r = await fetch(url, { headers: { "user-agent": "Mozilla/5.0" } });
  if (!r.ok) throw new Error(`Yahoo ${r.status}`);
  const j = (await r.json()) as YahooQuoteResp;
  return (j.quoteResponse?.result ?? []).map((q) => ({
    symbol: q.symbol,
    price: q.regularMarketPrice ?? 0,
    change: q.regularMarketChange ?? 0,
    changePct: (q.regularMarketChangePercent ?? 0) / 100,
  }));
}

async function fetchStooq(symbols: string[]) {
  // Fallback: stooq returns CSV; symbols like AAPL.US
  const out: Array<{ symbol: string; price: number; change: number; changePct: number }> = [];
  await Promise.all(symbols.map(async (s) => {
    const stooqSym = s.includes(".") ? s.toLowerCase() : `${s.toLowerCase()}.us`;
    const r = await fetch(`https://stooq.com/q/l/?s=${encodeURIComponent(stooqSym)}&f=sd2t2ohlcv&h&e=csv`);
    if (!r.ok) return;
    const t = await r.text();
    const lines = t.trim().split("\n");
    if (lines.length < 2) return;
    const cols = lines[1].split(",");
    const price = Number(cols[6]);
    if (!isFinite(price) || price === 0) return;
    out.push({ symbol: s, price, change: 0, changePct: 0 });
  }));
  return out;
}

export const Route = createFileRoute("/api/public/quotes")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const symbols = (url.searchParams.get("symbols") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
        if (symbols.length === 0) return Response.json({ quotes: [] });
        try {
          let quotes = await fetchYahoo(symbols);
          if (quotes.length === 0) quotes = await fetchStooq(symbols);
          return Response.json({ quotes });
        } catch (e) {
          // Try stooq fallback
          try {
            const quotes = await fetchStooq(symbols);
            return Response.json({ quotes });
          } catch {
            return Response.json({ quotes: [], error: (e as Error).message }, { status: 502 });
          }
        }
      },
    },
  },
});
