import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useDbReady, useQuery } from "@/lib/db/hooks";
import { exec, run, all, one } from "@/lib/db/sqlite";
import { bumpChange } from "@/lib/db/hooks";
import { insertTransaction, upsertSecurity } from "@/lib/db/dao";
import { useState } from "react";
import { toast } from "sonner";
import { fmtMoney } from "@/lib/format";

export const Route = createFileRoute("/distributions")({
  head: () => ({ meta: [{ title: "ETF Distributions — Ledger" }, { name: "description", content: "Import and approve ETF distribution classifications." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const { data: pending } = useQuery<{ id: number; symbol: string; ex_date: string | null; pay_date: string | null; total_per_unit: number; eligible_div: number; non_eligible_div: number; capital_gains: number; return_of_capital: number; interest: number; foreign_income: number; status: string; source_url: string | null }>(
    `SELECT * FROM pending_distributions WHERE status = 'pending' ORDER BY pay_date DESC, symbol`,
  );
  const [url, setUrl] = useState("");
  const [provider, setProvider] = useState("ishares-ca");
  const [loading, setLoading] = useState(false);

  async function importFromUrl() {
    if (!url.trim()) return;
    setLoading(true);
    try {
      const r = await fetch(`/api/public/etf-distributions?provider=${provider}&url=${encodeURIComponent(url)}`);
      const data = await r.json() as { distributions: Array<{ symbol: string; ex_date?: string; pay_date?: string; per_unit: number; classifications: Record<string, number> }>; error?: string };
      if (data.error) throw new Error(data.error);
      let n = 0;
      for (const d of data.distributions) {
        const c = d.classifications;
        await run(`INSERT INTO pending_distributions (symbol, ex_date, pay_date, total_per_unit, eligible_div, non_eligible_div, capital_gains, return_of_capital, interest, foreign_income, source_url)
          VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
          [d.symbol.toUpperCase(), d.ex_date ?? null, d.pay_date ?? null, d.per_unit,
           c.eligible_div ?? 0, c.non_eligible_div ?? 0, c.capital_gains ?? 0, c.return_of_capital ?? 0, c.interest ?? 0, c.foreign_income ?? 0, url]);
        n++;
      }
      bumpChange();
      toast.success(`Imported ${n} pending distributions`);
      setUrl("");
    } catch (e) {
      toast.error("Import failed: " + (e as Error).message);
    } finally { setLoading(false); }
  }

  async function approve(p: NonNullable<typeof pending>[number]) {
    // Find any account holding this symbol with non-zero qty; book each tax-type as separate transactions
    const sec = await one<{ id: number }>(`SELECT id FROM securities WHERE symbol = ?`, [p.symbol.toUpperCase()]);
    if (!sec) { toast.error("Symbol not held"); return; }
    const holdings = await all<{ account_id: number; qty: number }>(
      `SELECT account_id,
        SUM(CASE type WHEN 'BUY' THEN quantity WHEN 'SELL' THEN -quantity ELSE 0 END) as qty
        FROM transactions WHERE security_id = ? GROUP BY account_id HAVING qty > 0`, [sec.id]);
    if (holdings.length === 0) { toast.error("No active holdings"); return; }
    const date = p.pay_date || p.ex_date || new Date().toISOString().slice(0, 10);
    for (const h of holdings) {
      const map: Array<[string, string, number]> = [
        ["DIV","eligible/non-eligible div", (p.eligible_div + p.non_eligible_div) * h.qty],
        ["INT","interest", p.interest * h.qty],
        ["INT","foreign income", p.foreign_income * h.qty],
        ["CG_DIST","capital gains dist", p.capital_gains * h.qty],
        ["ROC","return of capital", p.return_of_capital * h.qty],
      ];
      for (const [type, note, amt] of map) {
        if (Math.abs(amt) < 0.005) continue;
        await insertTransaction({ account_id: h.account_id, security_id: sec.id, trade_date: date, type, amount: amt, notes: `${p.symbol} ${note}`, source: "etf_import" });
      }
    }
    await exec(`UPDATE pending_distributions SET status='approved' WHERE id = ?`, [p.id]);
    bumpChange();
    toast.success("Distribution applied");
  }

  async function reject(id: number) {
    await exec(`UPDATE pending_distributions SET status='rejected' WHERE id = ?`, [id]);
    bumpChange();
  }

  return (
    <div>
      <PageHeader title="ETF Distributions" description="Import classification data from ETF providers and approve before recording." />
      <Card><CardContent className="pt-6 space-y-3">
        <div className="grid md:grid-cols-3 gap-3 items-end">
          <div>
            <Label>Provider</Label>
            <Select value={provider} onValueChange={setProvider}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ishares-ca">iShares Canada</SelectItem>
                <SelectItem value="bmo">BMO ETFs</SelectItem>
                <SelectItem value="vanguard-ca">Vanguard Canada</SelectItem>
                <SelectItem value="generic">Generic CSV/HTML</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2"><Label>Distribution page URL</Label><Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://..." /></div>
        </div>
        <Button onClick={importFromUrl} disabled={loading}>{loading ? "Fetching…" : "Fetch distributions"}</Button>
        <p className="text-xs text-muted-foreground">Note: page structure varies by provider. Always review the parsed values below before approving.</p>
      </CardContent></Card>

      <Card className="mt-4"><CardContent className="pt-6 overflow-x-auto">
        <Table>
          <TableHeader><TableRow>
            <TableHead>Symbol</TableHead><TableHead>Pay date</TableHead><TableHead className="text-right">$/unit</TableHead>
            <TableHead className="text-right">Div</TableHead><TableHead className="text-right">Cap gains</TableHead>
            <TableHead className="text-right">ROC</TableHead><TableHead className="text-right">Interest</TableHead>
            <TableHead className="text-right">Foreign</TableHead><TableHead></TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {(pending ?? []).map((p) => (
              <TableRow key={p.id}>
                <TableCell><Badge>{p.symbol}</Badge></TableCell>
                <TableCell className="num">{p.pay_date ?? p.ex_date}</TableCell>
                <TableCell className="text-right num">{fmtMoney(p.total_per_unit)}</TableCell>
                <TableCell className="text-right num">{fmtMoney(p.eligible_div + p.non_eligible_div)}</TableCell>
                <TableCell className="text-right num">{fmtMoney(p.capital_gains)}</TableCell>
                <TableCell className="text-right num">{fmtMoney(p.return_of_capital)}</TableCell>
                <TableCell className="text-right num">{fmtMoney(p.interest)}</TableCell>
                <TableCell className="text-right num">{fmtMoney(p.foreign_income)}</TableCell>
                <TableCell className="flex gap-1 justify-end">
                  <Button size="sm" onClick={() => approve(p)}>Approve</Button>
                  <Button size="sm" variant="ghost" onClick={() => reject(p.id)}>Reject</Button>
                </TableCell>
              </TableRow>
            ))}
            {pending && pending.length === 0 && <TableRow><TableCell colSpan={9} className="text-center text-muted-foreground py-8">No pending distributions</TableCell></TableRow>}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
