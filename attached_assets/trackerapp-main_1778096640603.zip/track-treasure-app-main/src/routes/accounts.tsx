import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useDbReady, useQuery } from "@/lib/db/hooks";
import { exec, run, all } from "@/lib/db/sqlite";
import { bumpChange } from "@/lib/db/hooks";
import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { fmtMoney, gainColor } from "@/lib/format";
import { allCashBalances } from "@/lib/portfolio";
import { toast } from "sonner";

const ACCOUNT_TYPES = ["TFSA","RRSP","RESP","MARGIN","CASH","401K","IRA","ROTH"];

export const Route = createFileRoute("/accounts")({
  head: () => ({ meta: [{ title: "Accounts — Ledger" }, { name: "description", content: "Manage investment accounts and assign them to portfolios." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const { data: accounts } = useQuery<{ id: number; name: string; account_type: string; currency: string; institution: string | null; portfolio_id: number | null; portfolio_name: string | null; beneficiary: string | null }>(
    `SELECT a.*, p.name as portfolio_name FROM accounts a LEFT JOIN portfolios p ON p.id = a.portfolio_id ORDER BY a.account_type, a.name`,
  );
  const { data: portfolios } = useQuery<{ id: number; name: string }>(`SELECT id, name FROM portfolios ORDER BY name`);
  const [cashMap, setCashMap] = useState<Map<number, number>>(new Map());
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", type: "MARGIN", currency: "CAD", institution: "", portfolio_id: "", beneficiary: "" });

  useEffect(() => { allCashBalances().then(setCashMap); }, [accounts?.length]);

  async function create() {
    if (!form.name.trim()) return;
    await run(
      `INSERT INTO accounts (name, account_type, currency, institution, portfolio_id, beneficiary) VALUES (?,?,?,?,?,?)`,
      [form.name.trim(), form.type, form.currency, form.institution.trim() || null, form.portfolio_id ? Number(form.portfolio_id) : null, form.beneficiary.trim() || null],
    );
    setOpen(false);
    setForm({ name: "", type: "MARGIN", currency: "CAD", institution: "", portfolio_id: "", beneficiary: "" });
    bumpChange();
    toast.success("Account created");
  }

  async function remove(id: number) {
    if (!confirm("Delete account and all its transactions?")) return;
    await exec(`DELETE FROM accounts WHERE id = ?`, [id]);
    bumpChange();
  }

  return (
    <div>
      <PageHeader title="Accounts" description="Investment accounts (registered and non-registered)"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="size-4 mr-1" />New account</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New account</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Account name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} maxLength={80} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Type</Label>
                    <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{ACCOUNT_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Currency</Label>
                    <Select value={form.currency} onValueChange={(v) => setForm({ ...form, currency: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CAD">CAD</SelectItem>
                        <SelectItem value="USD">USD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div><Label>Institution</Label><Input value={form.institution} onChange={(e) => setForm({ ...form, institution: e.target.value })} maxLength={80} /></div>
                <div>
                  <Label>Portfolio</Label>
                  <Select value={form.portfolio_id} onValueChange={(v) => setForm({ ...form, portfolio_id: v })}>
                    <SelectTrigger><SelectValue placeholder="Unassigned" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">Unassigned</SelectItem>
                      {(portfolios ?? []).map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {form.type === "RESP" && (
                  <div><Label>Beneficiary (child name)</Label><Input value={form.beneficiary} onChange={(e) => setForm({ ...form, beneficiary: e.target.value })} maxLength={80} /></div>
                )}
              </div>
              <DialogFooter><Button onClick={create}>Create</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <Card>
        <CardContent className="pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Portfolio</TableHead>
                <TableHead>Currency</TableHead>
                <TableHead>Beneficiary</TableHead>
                <TableHead className="text-right">Cash balance</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(accounts ?? []).map((a) => {
                const cash = cashMap.get(a.id) ?? 0;
                return (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.name}<div className="text-xs text-muted-foreground">{a.institution}</div></TableCell>
                    <TableCell><Badge variant="secondary">{a.account_type}</Badge></TableCell>
                    <TableCell>{a.portfolio_name || <span className="text-muted-foreground">—</span>}</TableCell>
                    <TableCell>{a.currency}</TableCell>
                    <TableCell>{a.beneficiary || <span className="text-muted-foreground">—</span>}</TableCell>
                    <TableCell className={`text-right num ${gainColor(cash)}`}>{fmtMoney(cash, a.currency)}</TableCell>
                    <TableCell><Button size="icon" variant="ghost" onClick={() => remove(a.id)}><Trash2 className="size-4" /></Button></TableCell>
                  </TableRow>
                );
              })}
              {accounts && accounts.length === 0 && (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No accounts yet</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

void all;
