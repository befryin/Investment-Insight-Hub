import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useDbReady } from "@/lib/db/hooks";
import { useEffect, useMemo, useState } from "react";
import { computeHoldings, realizedGains, incomeBreakdown, type Holding } from "@/lib/portfolio";
import { fmtMoney, fmtPct, gainColor } from "@/lib/format";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend } from "recharts";

const COLORS = ["var(--color-chart-1)","var(--color-chart-2)","var(--color-chart-3)","var(--color-chart-4)","var(--color-chart-5)","var(--color-chart-6)","var(--color-chart-7)","var(--color-chart-8)"];

export const Route = createFileRoute("/reports")({
  head: () => ({ meta: [{ title: "Reports — Ledger" }, { name: "description", content: "Asset allocation, performance, capital gains and income reports." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [gains, setGains] = useState<Awaited<ReturnType<typeof realizedGains>>>([]);
  const [income, setIncome] = useState<Awaited<ReturnType<typeof incomeBreakdown>>>([]);
  const [year, setYear] = useState("all");
  const [incomeType, setIncomeType] = useState("all");

  useEffect(() => {
    computeHoldings().then(setHoldings);
    realizedGains().then(setGains);
  }, []);
  useEffect(() => {
    incomeBreakdown({
      year: year === "all" ? undefined : Number(year),
      type: incomeType === "all" ? undefined : incomeType,
    }).then(setIncome);
  }, [year, incomeType]);

  const allocByClass = useMemo(() => {
    const m = new Map<string, number>();
    holdings.forEach((h) => m.set(h.asset_class || "Unclassified", (m.get(h.asset_class || "Unclassified") ?? 0) + h.market_value));
    return Array.from(m, ([name, value]) => ({ name, value }));
  }, [holdings]);

  const allocByRegion = useMemo(() => {
    const m = new Map<string, number>();
    holdings.forEach((h) => m.set(h.region || "Unclassified", (m.get(h.region || "Unclassified") ?? 0) + h.market_value));
    return Array.from(m, ([name, value]) => ({ name, value }));
  }, [holdings]);

  const performance = useMemo(() => holdings.slice(0, 10).map((h) => ({
    name: h.symbol, gain: h.unrealized,
  })), [holdings]);

  const yearOptions = useMemo(() => Array.from(new Set(gains.map((g) => g.year))).sort((a, b) => b - a), [gains]);
  const filteredGains = year === "all" ? gains : gains.filter((g) => g.year === Number(year));
  const totalGain = filteredGains.reduce((s, g) => s + g.gain, 0);
  const totalIncome = income.reduce((s, r) => s + r.amount, 0);

  return (
    <div>
      <PageHeader title="Reports & charts" description="Asset allocation, performance, capital gains, and income breakdown." />

      <div className="grid gap-4 md:grid-cols-2">
        <ChartCard title="Allocation by asset class" data={allocByClass} />
        <ChartCard title="Allocation by region" data={allocByRegion} />
      </div>

      <Card className="mt-4">
        <CardHeader><CardTitle>Top holdings — unrealized P/L</CardTitle></CardHeader>
        <CardContent>
          {performance.length === 0 ? <Empty /> : (
            <div className="h-[300px]">
              <ResponsiveContainer>
                <BarChart data={performance}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="name" stroke="var(--color-muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--color-muted-foreground)" fontSize={12} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
                  <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }} formatter={(v: number) => fmtMoney(v)} />
                  <Bar dataKey="gain">
                    {performance.map((p, i) => <Cell key={i} fill={p.gain >= 0 ? "var(--color-gain)" : "var(--color-loss)"} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="mt-4">
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle>Realized capital gains</CardTitle>
            <div className="flex gap-2">
              <Select value={year} onValueChange={setYear}>
                <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All years</SelectItem>
                  {yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow><TableHead>Symbol</TableHead><TableHead>Year</TableHead><TableHead className="text-right">Proceeds</TableHead><TableHead className="text-right">Cost</TableHead><TableHead className="text-right">Gain/Loss</TableHead></TableRow></TableHeader>
            <TableBody>
              {filteredGains.map((g, i) => (
                <TableRow key={i}>
                  <TableCell>{g.symbol}</TableCell><TableCell>{g.year}</TableCell>
                  <TableCell className="text-right num">{fmtMoney(g.proceeds)}</TableCell>
                  <TableCell className="text-right num">{fmtMoney(g.cost)}</TableCell>
                  <TableCell className={`text-right num ${gainColor(g.gain)}`}>{fmtMoney(g.gain)}</TableCell>
                </TableRow>
              ))}
              {filteredGains.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">No realized gains</TableCell></TableRow>}
            </TableBody>
          </Table>
          {filteredGains.length > 0 && (
            <div className={`text-right pt-3 border-t border-border mt-3 num font-medium ${gainColor(totalGain)}`}>Total: {fmtMoney(totalGain)} {totalGain !== 0 && <span className="text-muted-foreground">({fmtPct(0)})</span>}</div>
          )}
        </CardContent>
      </Card>

      <Card className="mt-4">
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle>Investment income</CardTitle>
            <Select value={incomeType} onValueChange={setIncomeType}>
              <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="DIV">Dividends</SelectItem>
                <SelectItem value="INT">Interest</SelectItem>
                <SelectItem value="CG_DIST">Capital gains dist</SelectItem>
                <SelectItem value="ROC">Return of capital</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow><TableHead>Year</TableHead><TableHead>Type</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
            <TableBody>
              {income.map((r, i) => (
                <TableRow key={i}><TableCell>{r.year}</TableCell><TableCell>{r.type}</TableCell><TableCell className={`text-right num ${gainColor(r.amount)}`}>{fmtMoney(r.amount)}</TableCell></TableRow>
              ))}
              {income.length === 0 && <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-6">No income recorded</TableCell></TableRow>}
            </TableBody>
          </Table>
          {income.length > 0 && <div className="text-right pt-3 border-t border-border mt-3 num font-medium">Total: {fmtMoney(totalIncome)}</div>}
        </CardContent>
      </Card>
    </div>
  );
}

function ChartCard({ title, data }: { title: string; data: Array<{ name: string; value: number }> }) {
  return (
    <Card>
      <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
      <CardContent>
        {data.length === 0 ? <Empty /> : (
          <div className="h-[280px]">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={data} dataKey="value" nameKey="name" outerRadius={100}>
                  {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }} formatter={(v: number) => fmtMoney(v)} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function Empty() { return <div className="text-sm text-muted-foreground py-8 text-center">No data</div>; }
