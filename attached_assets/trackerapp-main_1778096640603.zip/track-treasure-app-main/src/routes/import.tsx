import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useDbReady, useQuery } from "@/lib/db/hooks";
import { useState } from "react";
import Papa from "papaparse";
import { insertTransaction, upsertSecurity } from "@/lib/db/dao";
import { toast } from "sonner";

const FIELDS = [
  { key: "trade_date", label: "Trade date *", required: true },
  { key: "type", label: "Type *", required: true },
  { key: "symbol", label: "Symbol" },
  { key: "quantity", label: "Quantity" },
  { key: "price", label: "Price" },
  { key: "amount", label: "Amount *", required: true },
  { key: "fees", label: "Fees" },
  { key: "currency", label: "Currency" },
  { key: "notes", label: "Notes" },
];

export const Route = createFileRoute("/import")({
  head: () => ({ meta: [{ title: "Import CSV — Ledger" }, { name: "description", content: "Import transactions from CSV with column mapping." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const { data: accounts } = useQuery<{ id: number; name: string }>(`SELECT id, name FROM accounts ORDER BY name`);
  const [accountId, setAccountId] = useState("");
  const [rows, setRows] = useState<Array<Record<string, string>>>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [importing, setImporting] = useState(false);

  function onFile(file: File) {
    Papa.parse<Record<string, string>>(file, {
      header: true, skipEmptyLines: true,
      complete: (res) => {
        setHeaders(res.meta.fields ?? []);
        setRows(res.data);
        const m: Record<string, string> = {};
        for (const f of FIELDS) {
          const guess = (res.meta.fields ?? []).find((h) => h.toLowerCase().replace(/[^a-z]/g, "") === f.key.replace(/_/g, ""));
          if (guess) m[f.key] = guess;
        }
        setMapping(m);
      },
    });
  }

  async function doImport() {
    if (!accountId) { toast.error("Select an account"); return; }
    for (const f of FIELDS.filter((f) => f.required)) {
      if (!mapping[f.key]) { toast.error(`Map column for ${f.label}`); return; }
    }
    setImporting(true);
    let ok = 0, fail = 0;
    for (const r of rows) {
      try {
        const symbol = mapping.symbol ? (r[mapping.symbol] ?? "").trim() : "";
        const secId = symbol ? await upsertSecurity(symbol) : null;
        await insertTransaction({
          account_id: Number(accountId),
          security_id: secId,
          trade_date: r[mapping.trade_date],
          type: r[mapping.type].toUpperCase(),
          quantity: Number(r[mapping.quantity] ?? 0) || 0,
          price: Number(r[mapping.price] ?? 0) || 0,
          amount: Number(r[mapping.amount] ?? 0) || 0,
          fees: Number(r[mapping.fees] ?? 0) || 0,
          currency: mapping.currency ? r[mapping.currency] : "CAD",
          notes: mapping.notes ? r[mapping.notes] : undefined,
          source: "csv",
        });
        ok++;
      } catch { fail++; }
    }
    setImporting(false);
    toast.success(`Imported ${ok} rows${fail ? `, ${fail} failed` : ""}`);
    setRows([]); setHeaders([]); setMapping({});
  }

  return (
    <div>
      <PageHeader title="Import CSV" description="Map your CSV columns to the app fields, then import." />
      <Card><CardContent className="pt-6 space-y-4">
        <div className="grid md:grid-cols-2 gap-3">
          <div>
            <Label>Account</Label>
            <Select value={accountId} onValueChange={setAccountId}>
              <SelectTrigger><SelectValue placeholder="Select account" /></SelectTrigger>
              <SelectContent>{(accounts ?? []).map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>CSV file</Label>
            <Input type="file" accept=".csv,text/csv" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
          </div>
        </div>

        {headers.length > 0 && (
          <>
            <div>
              <Label className="mb-2 block">Column mapping</Label>
              <div className="grid sm:grid-cols-2 gap-2">
                {FIELDS.map((f) => (
                  <div key={f.key} className="flex items-center gap-2">
                    <span className="text-sm w-32 shrink-0">{f.label}</span>
                    <Select value={mapping[f.key] ?? ""} onValueChange={(v) => setMapping({ ...mapping, [f.key]: v === "_none" ? "" : v })}>
                      <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="_none">—</SelectItem>
                        {headers.map((h) => <SelectItem key={h} value={h}>{h}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label>Preview ({rows.length} rows)</Label>
              <div className="overflow-x-auto max-h-64 border border-border rounded-md mt-2">
                <Table>
                  <TableHeader><TableRow>{headers.map((h) => <TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader>
                  <TableBody>
                    {rows.slice(0, 5).map((r, i) => (
                      <TableRow key={i}>{headers.map((h) => <TableCell key={h} className="text-xs">{r[h]}</TableCell>)}</TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <Button onClick={doImport} disabled={importing}>{importing ? "Importing…" : `Import ${rows.length} transactions`}</Button>
          </>
        )}
      </CardContent></Card>
    </div>
  );
}
