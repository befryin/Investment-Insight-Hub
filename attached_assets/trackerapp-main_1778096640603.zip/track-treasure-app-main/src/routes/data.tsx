import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useDbReady } from "@/lib/db/hooks";
import { exportDump } from "@/lib/db/sqlite";
import { Download } from "lucide-react";

export const Route = createFileRoute("/data")({
  head: () => ({ meta: [{ title: "Data & Backup — Ledger" }, { name: "description", content: "Backup and restore your local SQLite database." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;

  async function downloadDb() {
    const bytes = await exportDump();
    const ab = new ArrayBuffer(bytes.byteLength);
    new Uint8Array(ab).set(bytes);
    const blob = new Blob([ab], { type: "application/x-sqlite3" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `ledger-${new Date().toISOString().slice(0, 10)}.sqlite`;
    a.click();
  }

  return (
    <div>
      <PageHeader title="Data & backup" description="Your data lives in your browser via OPFS. Export periodic backups for safety." />
      <Card><CardContent className="pt-6 space-y-3">
        <p className="text-sm text-muted-foreground">All data stays on this device. Use the button below to download a full SQLite snapshot you can store anywhere.</p>
        <Button onClick={downloadDb}><Download className="size-4 mr-1" />Download database snapshot</Button>
      </CardContent></Card>
    </div>
  );
}
