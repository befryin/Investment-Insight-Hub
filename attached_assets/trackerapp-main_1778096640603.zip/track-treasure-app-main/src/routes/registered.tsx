import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useDbReady } from "@/lib/db/hooks";
import { useEffect, useState } from "react";
import { registeredSummary } from "@/lib/portfolio";
import { fmtMoney, gainColor } from "@/lib/format";

export const Route = createFileRoute("/registered")({
  head: () => ({ meta: [{ title: "Registered accounts — Ledger" }, { name: "description", content: "Track RRSP, TFSA, and RESP contributions and withdrawals." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const [data, setData] = useState<Awaited<ReturnType<typeof registeredSummary>>>([]);
  useEffect(() => { registeredSummary().then(setData); }, []);

  const grouped = data.reduce<Record<string, typeof data>>((acc, r) => {
    (acc[r.account_type] = acc[r.account_type] || []).push(r); return acc;
  }, {});

  return (
    <div>
      <PageHeader title="Registered accounts" description="RRSP, TFSA and RESP contributions and withdrawals (use CONTRIB / WITHDRAW_REG transaction types)." />
      {Object.keys(grouped).length === 0 && (
        <Card><CardContent className="pt-6 text-sm text-muted-foreground text-center">No registered accounts yet. Create RRSP/TFSA/RESP accounts and post CONTRIB transactions.</CardContent></Card>
      )}
      {Object.entries(grouped).map(([type, rows]) => (
        <Card key={type} className="mb-4">
          <CardHeader><CardTitle><Badge className="mr-2">{type}</Badge>{type === "RESP" ? "By beneficiary" : "Summary"}</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader><TableRow>
                <TableHead>Account</TableHead>
                {type === "RESP" && <TableHead>Beneficiary</TableHead>}
                <TableHead className="text-right">Contributions</TableHead>
                <TableHead className="text-right">Withdrawals</TableHead>
                <TableHead className="text-right">Net</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.account_id}>
                    <TableCell>{r.account_name}</TableCell>
                    {type === "RESP" && <TableCell>{r.beneficiary || <span className="text-muted-foreground">—</span>}</TableCell>}
                    <TableCell className="text-right num">{fmtMoney(r.contributions)}</TableCell>
                    <TableCell className="text-right num">{fmtMoney(r.withdrawals)}</TableCell>
                    <TableCell className={`text-right num ${gainColor(r.net)}`}>{fmtMoney(r.net)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
