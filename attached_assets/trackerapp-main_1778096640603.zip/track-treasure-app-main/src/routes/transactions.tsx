import { createFileRoute, Link } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useDbReady, useQuery } from "@/lib/db/hooks";
import { all } from "@/lib/db/sqlite";
import { insertTransaction, deleteTransaction, upsertSecurity } from "@/lib/db/dao";
import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { fmtMoney, gainColor } from "@/lib/format";
import { toast } from "sonner";

const TX_TYPES = ["BUY","SELL","DIV","INT","CG_DIST","ROC","FEE","DEPOSIT","WITHDRAWAL","CONTRIB","WITHDRAW_REG","SPLIT"];

export const Route = createFileRoute("/transactions")({
  head: () => ({ meta: [{ title: "Transactions — Ledger" }, { name: "description", content: "All investment transactions across accounts." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const [accountFilter, setAccountFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [year, setYear] = useState("all");

  let where = "1=1";
  const params: unknown[] = [];
  if (accountFilter !== "all") { where += " AND t.account_id = ?"; params.push(Number(accountFilter)); }
  if (typeFilter !== "all") { where += " AND t.type = ?"; params.push(typeFilter); }
  if (year !== "all") { where += " AND substr(t.trade_date,1,4) = ?"; params.push(year); }

  const { data: txs } = useQuery<{ id: number; trade_date: string; type: string; quantity: number; price: number; amount: number; symbol: string | null; account_name: string; currency: string }>(
    `SELECT t.id, t.trade_date, t.type, t.quantity, t.price, t.amount, t.currency, s.symbol, a.name as account_name
     FROM transactions t JOIN accounts a ON a.id = t.account_id LEFT JOIN securities s ON s.id = t.security_id
     WHERE ${where} ORDER BY t.trade_date DESC, t.id DESC LIMIT 500`, params,
  );
  const { data: accounts } = useQuery<{ id: number; name: string }>(`SELECT id, name FROM accounts ORDER BY name`);
  const { data: years } = useQuery<{ y: string }>(`SELECT DISTINCT substr(trade_date,1,4) as y FROM transactions ORDER BY y DESC`);

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    account_id: "", type: "BUY", trade_date: new Date().toISOString().slice(0, 10),
    symbol: "", quantity: "", price: "", amount: "", fees: "", notes: "",
  });

  async function submit() {
    if (!form.account_id) { toast.error("Pick an account"); return; }
    let secId: number | null = null;
    if (["BUY","SELL","DIV","INT","CG_DIST","ROC","SPLIT"].includes(form.type)) {
      if (!form.symbol.trim()) { toast.error("Symbol required"); return; }
      secId = await upsertSecurity(form.symbol.trim());
    }
    const qty = Number(form.quantity || 0), price = Number(form.price || 0), fees = Number(form.fees || 0);
    let amount = Number(form.amount || 0);
    if (form.type === "BUY") amount = -(qty * price + fees);
    else if (form.type === "SELL") amount = qty * price - fees;
    await insertTransaction({
      account_id: Number(form.account_id), security_id: secId, trade_date: form.trade_date,
      type: form.type, quantity: qty, price, amount, fees, notes: form.notes,
    });
    setOpen(false);
    setForm({ ...form, symbol: "", quantity: "", price: "", amount: "", fees: "", notes: "" });
    toast.success("Transaction added");
  }

  return (
    <div>
      <PageHeader title="Transactions" description="All buys, sells, dividends, contributions and more"
        actions={<Button onClick={() => setOpen(true)}><Plus className="size-4 mr-1" />New</Button>}
      />

      <div className="flex flex-wrap gap-2 mb-4">
        <Select value={accountFilter} onValueChange={setAccountFilter}>
          <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All accounts</SelectItem>
            {(accounts ?? []).map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            {TX_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={year} onValueChange={setYear}>
          <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All years</SelectItem>
            {(years ?? []).map((y) => <SelectItem key={y.y} value={y.y}>{y.y}</SelectItem>)}
          </SelectContent>
        </Select>
        <Link to="/import" className="ml-auto"><Button variant="outline">Import CSV</Button></Link>
      </div>

      <Card>
        <CardContent className="pt-6 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead><TableHead>Type</TableHead><TableHead>Symbol</TableHead>
                <TableHead>Account</TableHead><TableHead className="text-right">Qty</TableHead>
                <TableHead className="text-right">Price</TableHead><TableHead className="text-right">Amount</TableHead><TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(txs ?? []).map((t) => (
                <TableRow key={t.id}>
                  <TableCell className="num">{t.trade_date}</TableCell>
                  <TableCell><Badge variant="outline">{t.type}</Badge></TableCell>
                  <TableCell>{t.symbol || <span className="text-muted-foreground">—</span>}</TableCell>
                  <TableCell className="text-sm">{t.account_name}</TableCell>
                  <TableCell className="text-right num">{t.quantity || ""}</TableCell>
                  <TableCell className="text-right num">{t.price ? fmtMoney(t.price, t.currency) : ""}</TableCell>
                  <TableCell className={`text-right num ${gainColor(t.amount)}`}>{fmtMoney(t.amount, t.currency)}</TableCell>
                  <TableCell><Button size="icon" variant="ghost" onClick={() => deleteTransaction(t.id)}><Trash2 className="size-4" /></Button></TableCell>
                </TableRow>
              ))}
              {txs && txs.length === 0 && <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-8">No transactions</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>New transaction</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Account</Label>
              <Select value={form.account_id} onValueChange={(v) => setForm({ ...form, account_id: v })}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>{(accounts ?? []).map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TX_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Date</Label><Input type="date" value={form.trade_date} onChange={(e) => setForm({ ...form, trade_date: e.target.value })} /></div>
            <div><Label>Symbol</Label><Input value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value.toUpperCase() })} maxLength={20} /></div>
            <div><Label>Quantity</Label><Input type="number" step="any" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></div>
            <div><Label>Price</Label><Input type="number" step="any" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></div>
            <div><Label>Amount (override)</Label><Input type="number" step="any" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
            <div><Label>Fees</Label><Input type="number" step="any" value={form.fees} onChange={(e) => setForm({ ...form, fees: e.target.value })} /></div>
            <div className="col-span-2"><Label>Notes</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} maxLength={300} /></div>
          </div>
          <DialogFooter><Button onClick={submit}>Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

void all;
