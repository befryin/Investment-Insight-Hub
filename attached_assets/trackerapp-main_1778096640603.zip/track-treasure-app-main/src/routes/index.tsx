import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useDbReady, useQuery } from "@/lib/db/hooks";
import { fmtMoney, fmtPct, gainColor } from "@/lib/format";
import { useEffect, useState } from "react";
import { computeHoldings, totalPortfolioValue, allCashBalances, xirr, getCashflows } from "@/lib/portfolio";
import { Skeleton } from "@/components/ui/skeleton";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { ArrowUpRight, ArrowDownRight, Wallet, TrendingUp, Briefcase } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Ledger" },
      { name: "description", content: "Overview of your investments, performance and cash balances." },
    ],
  }),
  component: () => (
    <ClientOnly fallback={<DashboardSkeleton />}>
      <Dashboard />
    </ClientOnly>
  ),
});

function DashboardSkeleton() {
  return (
    <div>
      <PageHeader title="Dashboard" description="Overview of your portfolio" />
      <div className="grid gap-4 md:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
      </div>
    </div>
  );
}

function Dashboard() {
  const { ready, error } = useDbReady();
  if (error) return <ErrorBanner message={error} />;
  if (!ready) return <DashboardSkeleton />;
  return <DashboardInner />;
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div>
      <PageHeader title="Database error" />
      <Card><CardContent className="pt-6 text-sm text-destructive">{message}</CardContent></Card>
      <p className="text-xs text-muted-foreground mt-3">
        Tip: SQLite WASM with OPFS requires a secure context with cross-origin isolation. The app falls back to in-memory storage automatically.
      </p>
    </div>
  );
}

function DashboardInner() {
  const { data: accounts } = useQuery<{ id: number; name: string; account_type: string }>(`SELECT id, name, account_type FROM accounts`);
  const [totals, setTotals] = useState<{ market: number; book: number; cash: number } | null>(null);
  const [allocation, setAllocation] = useState<Array<{ name: string; value: number }>>([]);
  const [byAccount, setByAccount] = useState<Array<{ name: string; value: number; cash: number }>>([]);
  const [mwr, setMwr] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      const t = await totalPortfolioValue();
      setTotals(t);
      const holdings = await computeHoldings();
      const allocMap = new Map<string, number>();
      for (const h of holdings) {
        const k = h.asset_class || "Unclassified";
        allocMap.set(k, (allocMap.get(k) ?? 0) + h.market_value);
      }
      if (t.cash > 0) allocMap.set("Cash", (allocMap.get("Cash") ?? 0) + t.cash);
      setAllocation(Array.from(allocMap, ([name, value]) => ({ name, value })));

      const cashMap = await allCashBalances();
      const acctVals = new Map<number, number>();
      for (const h of holdings) acctVals.set(h.account_id, (acctVals.get(h.account_id) ?? 0) + h.market_value);
      const accts = await (await import("@/lib/db/sqlite")).all<{ id: number; name: string }>(`SELECT id, name FROM accounts`);
      setByAccount(accts.map((a) => ({ name: a.name, value: acctVals.get(a.id) ?? 0, cash: cashMap.get(a.id) ?? 0 })));

      // MWR
      const flows = await getCashflows();
      if (flows.length > 0 && t.market + t.cash > 0) {
        const all = [...flows, { date: new Date(), amount: t.market + t.cash }];
        setMwr(xirr(all));
      }
    })();
  }, [accounts?.length]);

  const totalValue = (totals?.market ?? 0) + (totals?.cash ?? 0);
  const gain = (totals?.market ?? 0) - (totals?.book ?? 0);
  const gainPct = totals?.book ? gain / totals.book : 0;

  const COLORS = ["var(--color-chart-1)","var(--color-chart-2)","var(--color-chart-3)","var(--color-chart-4)","var(--color-chart-5)","var(--color-chart-6)","var(--color-chart-7)","var(--color-chart-8)"];

  return (
    <div>
      <PageHeader title="Dashboard" description="Overview of your portfolio across all accounts" />
      <div className="grid gap-4 md:grid-cols-4">
        <Stat icon={<Briefcase className="size-4" />} label="Total Value" value={fmtMoney(totalValue)} />
        <Stat icon={<Wallet className="size-4" />} label="Cash" value={fmtMoney(totals?.cash ?? 0)} />
        <Stat icon={gain >= 0 ? <ArrowUpRight className="size-4" /> : <ArrowDownRight className="size-4" />}
              label="Unrealized P/L" value={fmtMoney(gain)} sub={fmtPct(gainPct)} valueClass={gainColor(gain)} />
        <Stat icon={<TrendingUp className="size-4" />} label="MWR (annualized)" value={mwr === null ? "—" : fmtPct(mwr)} />
      </div>

      <div className="grid gap-4 md:grid-cols-2 mt-6">
        <Card>
          <CardHeader><CardTitle>Asset allocation</CardTitle></CardHeader>
          <CardContent>
            {allocation.length === 0 ? (
              <EmptyHint />
            ) : (
              <div className="h-[280px]">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={allocation} dataKey="value" nameKey="name" innerRadius={60} outerRadius={100} paddingAngle={2}>
                      {allocation.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v: number) => fmtMoney(v)} contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8 }} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>By account</CardTitle></CardHeader>
          <CardContent>
            {byAccount.length === 0 ? <EmptyHint /> : (
              <div className="space-y-2">
                {byAccount.map((a) => (
                  <div key={a.name} className="flex items-center justify-between text-sm border-b border-border last:border-0 py-2">
                    <span>{a.name}</span>
                    <div className="text-right">
                      <div className="num">{fmtMoney(a.value + a.cash)}</div>
                      <div className="num text-xs text-muted-foreground">cash {fmtMoney(a.cash)}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Stat({ icon, label, value, sub, valueClass }: { icon: React.ReactNode; label: string; value: string; sub?: string; valueClass?: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between text-xs text-muted-foreground"><span>{label}</span>{icon}</div>
        <div className={`text-2xl font-semibold mt-2 num ${valueClass ?? ""}`}>{value}</div>
        {sub && <div className={`text-xs mt-1 num ${valueClass ?? "text-muted-foreground"}`}>{sub}</div>}
      </CardContent>
    </Card>
  );
}

function EmptyHint() {
  return (
    <div className="text-sm text-muted-foreground py-6 text-center">
      No data yet. Create an account and add transactions to get started.
    </div>
  );
}
