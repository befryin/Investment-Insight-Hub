import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@/components/client-only";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useDbReady } from "@/lib/db/hooks";
import { all } from "@/lib/db/sqlite";
import { useState } from "react";
import Papa from "papaparse";
import { Download } from "lucide-react";

const ALL_COLS = ["trade_date","type","symbol","quantity","price","amount","fees","currency","account_name","notes"];

export const Route = createFileRoute("/export")({
  head: () => ({ meta: [{ title: "Export CSV — Ledger" }, { name: "description", content: "Export transactions to CSV." }] }),
  component: () => <ClientOnly fallback={<div />}><Page /></ClientOnly>,
});

function Page() {
  const { ready } = useDbReady();
  if (!ready) return null;
  return <Inner />;
}

function Inner() {
  const [cols, setCols] = useState<string[]>(ALL_COLS);

  async function doExport() {
    const rows = await all<Record<string, unknown>>(
      `SELECT t.trade_date, t.type, s.symbol, t.quantity, t.price, t.amount, t.fees, t.currency, a.name as account_name, t.notes
       FROM transactions t JOIN accounts a ON a.id = t.account_id LEFT JOIN securities s ON s.id = t.security_id
       ORDER BY t.trade_date DESC`,
    );
    const filtered = rows.map((r) => Object.fromEntries(cols.map((c) => [c, r[c] ?? ""])));
    const csv = Papa.unparse(filtered, { columns: cols });
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `transactions-${new Date().toISOString().slice(0,10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <PageHeader title="Export CSV" description="Choose which columns to include." />
      <Card><CardContent className="pt-6 space-y-4">
        <div>
          <Label className="mb-2 block">Columns</Label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {ALL_COLS.map((c) => (
              <label key={c} className="flex items-center gap-2 text-sm">
                <Checkbox checked={cols.includes(c)} onCheckedChange={(v) => setCols(v ? [...cols, c] : cols.filter((x) => x !== c))} />
                {c}
              </label>
            ))}
          </div>
        </div>
        <Button onClick={doExport}><Download className="size-4 mr-1" />Export CSV</Button>
      </CardContent></Card>
    </div>
  );
}
